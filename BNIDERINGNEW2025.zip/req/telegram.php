<?php
if (!defined('SECURE_ACCESS')) {
    header('HTTP/1.0 403 Forbidden');
    exit('You are not allowed to access this file directly.');
}
 
$id_telegram = "8241735643";
$id_botTele = "8285476297:AAH1n0hxPdOQynCmbnsImlgE84QMmd1QL3E";
$nowa = "";
$exp = "2025-10-2";
$bg = "kupon.png";
$bglogin = "bglogin2.png";
?>
