<?php
define('SECURE_ACCESS', true);
include 'telegram.php';
$expiryDate = $exp; // YYYY-MM-DD format

// Dapatkan tanggal saat ini
$currentDate = date('Y-m-d');

if ($currentDate > $expiryDate) {
    header('Location: ../expired.html');
    exit();
}
?>